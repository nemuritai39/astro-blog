// Place any global data in this file.
// You can import this data from anywhere in your site by using the `import` keyword.

// Brand
// 站点左上角名称（全站一致）
export const SITE_TITLE = 'nemu · archive';
export const SITE_DESCRIPTION = 'notes · poems · thinking · goals';
