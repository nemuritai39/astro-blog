import { defineCollection, z } from "astro:content";

const baseSchema = z.object({
  title: z.string(),
  description: z.string().optional(),
  pubDate: z.coerce.date(),
  updatedDate: z.coerce.date().optional(),
  draft: z.boolean().optional().default(false),
});

export const collections = {
  essays: defineCollection({ type: "content", schema: baseSchema }),
  poems: defineCollection({ type: "content", schema: baseSchema }),
  thinking: defineCollection({ type: "content", schema: baseSchema }),
  goals: defineCollection({ type: "content", schema: baseSchema }),
};
