---
title: "（示例）一首短诗"
description: "夜 / 冬"
pubDate: 2026-02-11
draft: false
---

这里是诗的正文。
